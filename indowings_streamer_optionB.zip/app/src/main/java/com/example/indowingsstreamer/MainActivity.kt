package com.example.indowingsstreamer

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var logsAdapter: LogsAdapter

    private val captureRequestLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val intent = Intent(this, ScreenCaptureService::class.java)
            intent.putExtra("projection_result_code", result.resultCode)
            intent.putExtra("projection_data", result.data)
            intent.putExtra("rtmp_url", findViewById<EditText>(R.id.edit_rtmp_url).text.toString())
            intent.putExtra("bitrate_kbps", getSelectedBitrate())
            intent.putExtra("fps", getSelectedFps())
            intent.putExtra("resolution", getSelectedResolution())
            intent.putExtra("codec", getSelectedCodec())
            startForegroundService(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val spinnerBitrate = findViewById<Spinner>(R.id.spinner_bitrate)
        val spinnerFps = findViewById<Spinner>(R.id.spinner_fps)
        val spinnerRes = findViewById<Spinner>(R.id.spinner_res)
        val spinnerCodec = findViewById<Spinner>(R.id.spinner_codec)

        spinnerBitrate.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("800", "1200", "2000", "2500", "4000"))

        spinnerFps.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("15", "24", "30", "60"))

        spinnerRes.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("480x854", "720x1280", "1280x720", "1920x1080"))

        spinnerCodec.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("H264", "H265"))

        findViewById<Button>(R.id.btn_start).setOnClickListener {
            val captureIntent = projectionManager.createScreenCaptureIntent()
            captureRequestLauncher.launch(captureIntent)
        }

        findViewById<Button>(R.id.btn_stop).setOnClickListener {
            val stopIntent = Intent(this, ScreenCaptureService::class.java)
            stopIntent.action = ScreenCaptureService.ACTION_STOP
            startService(stopIntent)
        }

        val rv = findViewById<RecyclerView>(R.id.recycler_logs)
        logsAdapter = LogsAdapter()
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = logsAdapter
    }

    private fun getSelectedBitrate(): Int {
        val s = findViewById<Spinner>(R.id.spinner_bitrate)
        return s.selectedItem.toString().toInt()
    }

    private fun getSelectedFps(): Int {
        val s = findViewById<Spinner>(R.id.spinner_fps)
        return s.selectedItem.toString().toInt()
    }

    private fun getSelectedResolution(): String {
        val s = findViewById<Spinner>(R.id.spinner_res)
        return s.selectedItem.toString()
    }

    private fun getSelectedCodec(): String {
        val s = findViewById<Spinner>(R.id.spinner_codec)
        return s.selectedItem.toString()
    }
}
