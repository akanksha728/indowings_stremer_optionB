package com.example.indowingsstreamer

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class ScreenCaptureService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var streamManager: StreamManager? = null
    private val CHANNEL_ID = "IndoWingsStreamChannel"

    companion object {
        const val ACTION_STOP = "ACTION_STOP_STREAM"
    }

    override fun onCreate() {
        super.onCreate()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopStreaming()
            stopSelf()
            return START_NOT_STICKY
        }

        val rtmpUrl = intent?.getStringExtra("rtmp_url") ?: ""
        val resultCode = intent?.getIntExtra("projection_result_code", Activity.RESULT_CANCELED)
        val data = intent?.getParcelableExtra<Intent>("projection_data")

        val bitrateKbps = intent?.getIntExtra("bitrate_kbps", 1200) ?: 1200
        val fps = intent?.getIntExtra("fps", 30) ?: 30
        val resolution = intent?.getStringExtra("resolution") ?: "720x1280"
        val codec = intent?.getStringExtra("codec") ?: "H264"

        val dims = resolution.split("x")
        val width = dims.getOrNull(0)?.toIntOrNull() ?: 720
        val height = dims.getOrNull(1)?.toIntOrNull() ?: 1280

        if (resultCode != null and (data != null)) {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = mpm.getMediaProjection(resultCode, data)

            streamManager = StreamManager(this)
            mediaProjection?.let {
                streamManager?.init(it, width, height, fps, bitrateKbps, codec)
                if (rtmpUrl.isNotEmpty()) {
                    streamManager?.start(rtmpUrl)
                }
            }
        }

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("IndoWings Live")
            .setContentText("Streaming in background")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(CHANNEL_ID, "IndoWings Stream", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(channel)
        }

        startForeground(1, notification)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        stopStreaming()
        mediaProjection?.stop()
        super.onDestroy()
    }

    private fun stopStreaming() {
        try {
            streamManager?.stop()
            streamManager?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
