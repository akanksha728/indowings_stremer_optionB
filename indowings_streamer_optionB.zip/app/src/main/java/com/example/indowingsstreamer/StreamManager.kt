package com.example.indowingsstreamer

import android.content.Context
import android.media.MediaMuxer
import android.util.Log
import com.pedro.rtplibrary.rtmp.RtmpDisplay
import kotlinx.coroutines.*

class StreamManager(private val context: Context) {

    private var rtmpDisplay: RtmpDisplay? = null
    private var currentUrl: String? = null
    private var job: Job? = null
    private var reconnectAttempts = 0

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var mediaMuxer: MediaMuxer? = null
    private var recordingPath: String? = null

    fun init(mediaProjection: android.media.projection.MediaProjection, width: Int, height: Int, fps: Int, bitrateKbps: Int, codec: String) {
        rtmpDisplay = RtmpDisplay(context, true)
        val bitrate = bitrateKbps * 1024
        try {
            rtmpDisplay?.prepareVideo(width, height, fps, bitrate, 0)
            rtmpDisplay?.setScreenDisplay(mediaProjection, width, height, 1)
        } catch (e: Exception) {
            Log.e("StreamManager", "prepareVideo/setScreenDisplay failed: $e")
        }
    }

    fun start(url: String) {
        currentUrl = url
        reconnectAttempts = 0
        tryStart()
    }

    private fun tryStart() {
        job?.cancel()
        job = scope.launch {
            try {
                currentUrl?.let {
                    rtmpDisplay?.startStream(it)
                    reconnectAttempts = 0
                    log("Streaming to $it")
                }
            } catch (e: Exception) {
                log("Start failed: $e")
                scheduleReconnect()
            }
        }
    }

    private fun scheduleReconnect() {
        reconnectAttempts++
        val delayMs = (kotlin.math.min(30, kotlin.math.pow(2.0, reconnectAttempts.toDouble()).toInt()) * 1000).toLong()
        log("Reconnect in $delayMs ms (attempt $reconnectAttempts)")
        scope.launch {
            kotlinx.coroutines.delay(delayMs)
            tryStart()
        }
    }

    fun stop() {
        try {
            rtmpDisplay?.stopStream()
            rtmpDisplay?.release()
            job?.cancel()
            log("Stopped streaming")
        } catch (e: Exception) {
            log("Stop error: $e")
        }
    }

    fun startSrt(url: String) {
        log("SRT start requested for $url - SRT client not implemented in this starter")
    }

    fun startRtsp(url: String) {
        log("RTSP start requested for $url - depending on library support")
    }

    private fun log(msg: String) {
        Log.i("StreamManager", msg)
    }

    fun release() {
        stop()
        scope.cancel()
    }
}
